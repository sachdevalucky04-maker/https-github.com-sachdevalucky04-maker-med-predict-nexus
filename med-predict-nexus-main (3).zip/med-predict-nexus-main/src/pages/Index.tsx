import { useState, useEffect } from "react";
import { PatientForm, PatientData } from "@/components/PatientForm";
import { RiskDashboard, RiskAssessment } from "@/components/RiskDashboard";
import { PatientRecords, PatientRecord } from "@/components/PatientRecords";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { calculateCancerRisk } from "@/utils/riskCalculator";
import { savePatientRecord, getPatientRecords, generateSampleData } from "@/utils/patientStorage";
import { Stethoscope, Brain, BarChart3, Users, AlertCircle } from "lucide-react";

const Index = () => {
  const [activeTab, setActiveTab] = useState("assessment");
  const [currentPatient, setCurrentPatient] = useState<PatientData | null>(null);
  const [currentAssessment, setCurrentAssessment] = useState<RiskAssessment | null>(null);
  const [patientRecords, setPatientRecords] = useState<PatientRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Load existing patient records and generate sample data if needed
    generateSampleData();
    setPatientRecords(getPatientRecords());
  }, []);

  const handlePatientSubmit = async (patientData: PatientData) => {
    setIsLoading(true);
    
    try {
      // Simulate processing time for ML prediction
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Calculate risk assessment
      const assessment = calculateCancerRisk(patientData);
      
      // Save patient record
      const savedRecord = savePatientRecord(patientData);
      
      // Update state
      setCurrentPatient(patientData);
      setCurrentAssessment(assessment);
      setPatientRecords(getPatientRecords());
      
      // Switch to results tab
      setActiveTab("results");
      
      toast({
        title: "Analysis Complete",
        description: `Risk assessment completed for ${patientData.name}`,
      });
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "There was an error processing the patient data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPatient = (record: PatientRecord) => {
    setCurrentPatient(record);
    setActiveTab("assessment");
  };

  const handleViewAssessment = (record: PatientRecord) => {
    const assessment = calculateCancerRisk(record);
    setCurrentPatient(record);
    setCurrentAssessment(assessment);
    setActiveTab("results");
  };

  const handleNewAssessment = () => {
    setCurrentPatient(null);
    setCurrentAssessment(null);
    setActiveTab("assessment");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-medical">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-primary rounded-xl">
                <Brain className="h-8 w-8 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Cancer Risk Prediction System</h1>
                <p className="text-muted-foreground">AI-powered healthcare risk assessment platform</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="text-primary border-primary">
                <AlertCircle className="h-4 w-4 mr-2" />
                Medical Grade AI
              </Badge>
              <Button 
                onClick={handleNewAssessment}
                className="bg-gradient-primary hover:opacity-90"
              >
                New Assessment
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
            <TabsTrigger value="assessment" className="flex items-center gap-2">
              <Stethoscope className="h-4 w-4" />
              Assessment
            </TabsTrigger>
            <TabsTrigger value="results" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Results
            </TabsTrigger>
            <TabsTrigger value="records" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Records
            </TabsTrigger>
          </TabsList>

          {/* Patient Assessment Tab */}
          <TabsContent value="assessment" className="space-y-6">
            <PatientForm
              onSubmit={handlePatientSubmit}
              initialData={currentPatient || undefined}
              isLoading={isLoading}
            />
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-6">
            {currentAssessment && currentPatient ? (
              <RiskDashboard 
                assessment={currentAssessment}
                patientName={currentPatient.name}
              />
            ) : (
              <Card className="shadow-medical">
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Assessment Available</h3>
                  <p className="text-muted-foreground text-center mb-4">
                    Complete a patient assessment to view detailed risk analysis and recommendations.
                  </p>
                  <Button onClick={handleNewAssessment} className="bg-gradient-primary hover:opacity-90">
                    Start New Assessment
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Patient Records Tab */}
          <TabsContent value="records" className="space-y-6">
            <PatientRecords
              records={patientRecords}
              onSelectPatient={handleSelectPatient}
              onViewAssessment={handleViewAssessment}
            />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-muted-foreground">
              © 2024 Cancer Risk Prediction System. Advanced healthcare analytics.
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Model Accuracy: 89.5%</span>
              <span>•</span>
              <span>FDA Compliant</span>
              <span>•</span>
              <span>HIPAA Secure</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
