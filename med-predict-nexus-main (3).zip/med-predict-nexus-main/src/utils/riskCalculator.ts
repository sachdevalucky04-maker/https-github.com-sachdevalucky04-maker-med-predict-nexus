import { PatientData } from "@/components/PatientForm";
import { RiskAssessment } from "@/components/RiskDashboard";

/**
 * Mock Machine Learning Risk Calculator
 * Simulates a comprehensive cancer risk assessment based on patient data
 * In a real application, this would interface with actual ML models
 */

export function calculateCancerRisk(patientData: PatientData): RiskAssessment {
  // Age risk calculation
  const ageRisk = calculateAgeRisk(patientData.age);
  
  // Lifestyle risk calculation
  const lifestyleRisk = calculateLifestyleRisk(patientData);
  
  // Genetic risk calculation
  const geneticRisk = calculateGeneticRisk(patientData);
  
  // Symptom risk calculation
  const symptomRisk = calculateSymptomRisk(patientData);
  
  // Test results risk calculation
  const testResultsRisk = calculateTestResultsRisk(patientData);
  
  // Weighted overall risk calculation
  const overallRisk = Math.round(
    (ageRisk * 0.25) +
    (lifestyleRisk * 0.30) +
    (geneticRisk * 0.20) +
    (symptomRisk * 0.15) +
    (testResultsRisk * 0.10)
  );
  
  // Determine risk level
  const riskLevel = getRiskLevel(overallRisk);
  
  // Calculate confidence based on data completeness
  const confidence = calculateConfidence(patientData);
  
  // Generate recommendations
  const recommendations = generateRecommendations(patientData, overallRisk);
  
  return {
    overallRisk: Math.min(100, Math.max(0, overallRisk)),
    riskLevel,
    confidence,
    factors: {
      age: ageRisk,
      lifestyle: lifestyleRisk,
      genetics: geneticRisk,
      symptoms: symptomRisk,
      testResults: testResultsRisk,
    },
    recommendations,
    modelAccuracy: 89.5, // Mock model accuracy
  };
}

function calculateAgeRisk(age: number): number {
  if (age < 30) return 5;
  if (age < 40) return 10;
  if (age < 50) return 20;
  if (age < 60) return 35;
  if (age < 70) return 50;
  return 65;
}

function calculateLifestyleRisk(data: PatientData): number {
  let risk = 0;
  
  // Smoking history
  switch (data.smokingHistory) {
    case "current":
      risk += 40;
      break;
    case "former":
      risk += 20;
      break;
    case "never":
      risk += 0;
      break;
    default:
      risk += 10;
  }
  
  // Alcohol consumption
  switch (data.alcoholConsumption) {
    case "heavy":
      risk += 25;
      break;
    case "moderate":
      risk += 15;
      break;
    case "light":
      risk += 5;
      break;
    case "none":
      risk += 0;
      break;
    default:
      risk += 5;
  }
  
  // Physical activity (inverse correlation)
  switch (data.physicalActivity) {
    case "sedentary":
      risk += 20;
      break;
    case "light":
      risk += 10;
      break;
    case "moderate":
      risk += 0;
      break;
    case "intense":
      risk -= 10;
      break;
    default:
      risk += 5;
  }
  
  return Math.min(100, Math.max(0, risk));
}

function calculateGeneticRisk(data: PatientData): number {
  let risk = 0;
  
  // Family history
  switch (data.familyHistory) {
    case "immediate":
      risk += 50;
      break;
    case "close":
      risk += 30;
      break;
    case "distant":
      risk += 15;
      break;
    case "none":
      risk += 0;
      break;
    default:
      risk += 10;
  }
  
  // Previous cancer history
  if (data.previousCancer) {
    risk += 40;
  }
  
  return Math.min(100, Math.max(0, risk));
}

function calculateSymptomRisk(data: PatientData): number {
  let risk = 0;
  
  // Check for concerning symptoms
  const concerningSymptoms = [
    "unexplained weight loss",
    "persistent fatigue",
    "unusual bleeding",
    "persistent cough",
    "changes in bowel habits",
    "unusual lumps",
    "skin changes",
    "persistent pain"
  ];
  
  const symptoms = [data.symptom1, data.symptom2].filter(Boolean).map(s => s.toLowerCase());
  
  symptoms.forEach(symptom => {
    if (concerningSymptoms.some(concerning => symptom.includes(concerning))) {
      risk += 30;
    } else if (symptom.trim()) {
      risk += 10;
    }
  });
  
  return Math.min(100, Math.max(0, risk));
}

function calculateTestResultsRisk(data: PatientData): number {
  let risk = 0;
  
  // BMI assessment
  if (data.testResults.bmi) {
    if (data.testResults.bmi > 30) {
      risk += 20; // Obese
    } else if (data.testResults.bmi > 25) {
      risk += 10; // Overweight
    }
  }
  
  // Cholesterol levels
  if (data.testResults.cholesterol) {
    if (data.testResults.cholesterol > 240) {
      risk += 15;
    } else if (data.testResults.cholesterol > 200) {
      risk += 8;
    }
  }
  
  // Blood sugar levels
  if (data.testResults.bloodSugar) {
    if (data.testResults.bloodSugar > 126) {
      risk += 15; // Diabetic range
    } else if (data.testResults.bloodSugar > 100) {
      risk += 8; // Pre-diabetic range
    }
  }
  
  return Math.min(100, Math.max(0, risk));
}

function getRiskLevel(overallRisk: number): "Low" | "Medium" | "High" {
  if (overallRisk < 30) return "Low";
  if (overallRisk < 60) return "Medium";
  return "High";
}

function calculateConfidence(data: PatientData): number {
  let completeness = 0;
  let totalFields = 0;
  
  // Basic information (required)
  totalFields += 3;
  if (data.name) completeness++;
  if (data.age) completeness++;
  if (data.gender) completeness++;
  
  // Lifestyle factors
  totalFields += 3;
  if (data.smokingHistory) completeness++;
  if (data.alcoholConsumption) completeness++;
  if (data.physicalActivity) completeness++;
  
  // Medical history
  totalFields += 2;
  if (data.familyHistory) completeness++;
  if (data.previousCancer !== undefined) completeness++;
  
  // Test results
  totalFields += 4;
  if (data.testResults.bloodPressure) completeness++;
  if (data.testResults.cholesterol) completeness++;
  if (data.testResults.bloodSugar) completeness++;
  if (data.testResults.bmi) completeness++;
  
  // Symptoms
  totalFields += 2;
  if (data.symptom1) completeness++;
  if (data.symptom2) completeness++;
  
  const completenessRatio = completeness / totalFields;
  return Math.round(completenessRatio * 100);
}

function generateRecommendations(data: PatientData, overallRisk: number): string[] {
  const recommendations: string[] = [];
  
  // Age-based recommendations
  if (data.age >= 50) {
    recommendations.push("Schedule regular cancer screening tests appropriate for your age group");
  }
  
  // Lifestyle recommendations
  if (data.smokingHistory === "current") {
    recommendations.push("Smoking cessation is critical - consult with healthcare provider about cessation programs");
  }
  
  if (data.alcoholConsumption === "heavy") {
    recommendations.push("Consider reducing alcohol consumption to lower cancer risk");
  }
  
  if (data.physicalActivity === "sedentary") {
    recommendations.push("Increase physical activity to at least 150 minutes of moderate exercise per week");
  }
  
  // BMI recommendations
  if (data.testResults.bmi > 25) {
    recommendations.push("Maintain a healthy weight through balanced diet and regular exercise");
  }
  
  // Family history recommendations
  if (data.familyHistory === "immediate" || data.familyHistory === "close") {
    recommendations.push("Discuss genetic counseling and enhanced screening protocols with your doctor");
  }
  
  // Risk-level specific recommendations
  if (overallRisk >= 60) {
    recommendations.push("Urgent consultation with an oncologist is recommended for comprehensive evaluation");
    recommendations.push("Consider additional diagnostic tests including advanced imaging studies");
  } else if (overallRisk >= 30) {
    recommendations.push("Schedule follow-up appointment with primary care physician within 2-4 weeks");
    recommendations.push("Monitor symptoms closely and report any changes immediately");
  } else {
    recommendations.push("Continue routine health maintenance and annual check-ups");
    recommendations.push("Maintain healthy lifestyle practices to minimize future risk");
  }
  
  // General recommendations
  recommendations.push("Follow a diet rich in fruits, vegetables, and whole grains");
  recommendations.push("Stay up to date with age-appropriate cancer screening guidelines");
  
  return recommendations;
}