import { PatientData } from "@/components/PatientForm";
import { PatientRecord } from "@/components/PatientRecords";
import { calculateCancerRisk } from "./riskCalculator";

const STORAGE_KEY = "cancer_prediction_patients";

export function savePatientRecord(patientData: PatientData): PatientRecord {
  const existingRecords = getPatientRecords();
  
  // Calculate risk assessment
  const riskAssessment = calculateCancerRisk(patientData);
  
  // Create new record
  const newRecord: PatientRecord = {
    ...patientData,
    id: patientData.id || generatePatientId(),
    dateCreated: new Date().toISOString(),
    lastAssessment: new Date().toISOString(),
    riskLevel: riskAssessment.riskLevel,
    riskScore: riskAssessment.overallRisk,
  };
  
  // Update existing record or add new one
  const recordIndex = existingRecords.findIndex(record => record.id === newRecord.id);
  if (recordIndex >= 0) {
    existingRecords[recordIndex] = newRecord;
  } else {
    existingRecords.push(newRecord);
  }
  
  // Save to localStorage
  localStorage.setItem(STORAGE_KEY, JSON.stringify(existingRecords));
  
  return newRecord;
}

export function getPatientRecords(): PatientRecord[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error("Error loading patient records:", error);
    return [];
  }
}

export function getPatientRecord(id: string): PatientRecord | null {
  const records = getPatientRecords();
  return records.find(record => record.id === id) || null;
}

export function deletePatientRecord(id: string): boolean {
  try {
    const records = getPatientRecords();
    const filteredRecords = records.filter(record => record.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filteredRecords));
    return true;
  } catch (error) {
    console.error("Error deleting patient record:", error);
    return false;
  }
}

function generatePatientId(): string {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 8);
  return `PAT-${timestamp}-${randomStr}`.toUpperCase();
}

// Generate sample data for demonstration
export function generateSampleData(): void {
  const samplePatients: PatientData[] = [
    {
      name: "John Smith",
      age: 65,
      gender: "male",
      smokingHistory: "former",
      alcoholConsumption: "light",
      physicalActivity: "moderate",
      familyHistory: "close",
      previousCancer: false,
      symptom1: "persistent cough",
      symptom2: "fatigue",
      testResults: {
        bloodPressure: "140/90",
        cholesterol: 220,
        bloodSugar: 105,
        bmi: 28.5,
      },
      medicalHistory: "Hypertension, managed with medication. No other significant medical history.",
    },
    {
      name: "Sarah Johnson",
      age: 42,
      gender: "female",
      smokingHistory: "never",
      alcoholConsumption: "moderate",
      physicalActivity: "intense",
      familyHistory: "none",
      previousCancer: false,
      symptom1: "",
      symptom2: "",
      testResults: {
        bloodPressure: "120/80",
        cholesterol: 180,
        bloodSugar: 95,
        bmi: 23.2,
      },
      medicalHistory: "Regular exercise routine, no significant medical history.",
    },
    {
      name: "Robert Davis",
      age: 58,
      gender: "male",
      smokingHistory: "current",
      alcoholConsumption: "heavy",
      physicalActivity: "sedentary",
      familyHistory: "immediate",
      previousCancer: true,
      symptom1: "unexplained weight loss",
      symptom2: "unusual fatigue",
      testResults: {
        bloodPressure: "150/95",
        cholesterol: 280,
        bloodSugar: 130,
        bmi: 32.1,
      },
      medicalHistory: "Previous colorectal cancer (treated 2019), diabetes type 2, hypertension.",
    },
    {
      name: "Maria Garcia",
      age: 35,
      gender: "female",
      smokingHistory: "never",
      alcoholConsumption: "none",
      physicalActivity: "light",
      familyHistory: "distant",
      previousCancer: false,
      symptom1: "",
      symptom2: "",
      testResults: {
        bloodPressure: "115/75",
        cholesterol: 165,
        bloodSugar: 88,
        bmi: 21.8,
      },
      medicalHistory: "No significant medical history. Regular health check-ups.",
    },
  ];

  // Only generate sample data if no records exist
  const existingRecords = getPatientRecords();
  if (existingRecords.length === 0) {
    samplePatients.forEach(patient => {
      savePatientRecord(patient);
    });
  }
}