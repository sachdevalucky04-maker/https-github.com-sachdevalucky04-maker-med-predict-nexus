import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from "recharts";
import { AlertTriangle, CheckCircle, Activity, TrendingUp } from "lucide-react";

export interface RiskAssessment {
  overallRisk: number;
  riskLevel: "Low" | "Medium" | "High";
  confidence: number;
  factors: {
    age: number;
    lifestyle: number;
    genetics: number;
    symptoms: number;
    testResults: number;
  };
  recommendations: string[];
  modelAccuracy: number;
}

interface RiskDashboardProps {
  assessment: RiskAssessment;
  patientName: string;
}

const COLORS = {
  Low: '#10b981',
  Medium: '#f59e0b', 
  High: '#ef4444'
};

const RISK_COLORS = ['#10b981', '#f59e0b', '#ef4444'];

export function RiskDashboard({ assessment, patientName }: RiskDashboardProps) {
  const factorData = [
    { name: 'Age', value: assessment.factors.age, fill: '#3b82f6' },
    { name: 'Lifestyle', value: assessment.factors.lifestyle, fill: '#8b5cf6' },
    { name: 'Genetics', value: assessment.factors.genetics, fill: '#06b6d4' },
    { name: 'Symptoms', value: assessment.factors.symptoms, fill: '#f59e0b' },
    { name: 'Test Results', value: assessment.factors.testResults, fill: '#10b981' },
  ];

  const riskDistribution = [
    { name: 'Low Risk', value: assessment.riskLevel === 'Low' ? 100 : 0, fill: COLORS.Low },
    { name: 'Medium Risk', value: assessment.riskLevel === 'Medium' ? 100 : 0, fill: COLORS.Medium },
    { name: 'High Risk', value: assessment.riskLevel === 'High' ? 100 : 0, fill: COLORS.High },
  ];

  const trendData = [
    { month: 'Baseline', risk: 20 },
    { month: 'Current', risk: assessment.overallRisk },
    { month: 'Projected (3mo)', risk: Math.max(0, assessment.overallRisk - 5) },
    { month: 'Projected (6mo)', risk: Math.max(0, assessment.overallRisk - 10) },
  ];

  const getRiskIcon = () => {
    switch (assessment.riskLevel) {
      case 'Low':
        return <CheckCircle className="h-6 w-6 text-accent" />;
      case 'Medium':
        return <Activity className="h-6 w-6 text-warning" />;
      case 'High':
        return <AlertTriangle className="h-6 w-6 text-destructive" />;
    }
  };

  const getRiskBadgeColor = () => {
    switch (assessment.riskLevel) {
      case 'Low':
        return 'bg-gradient-success text-accent-foreground';
      case 'Medium':
        return 'bg-gradient-warning text-warning-foreground';
      case 'High':
        return 'bg-gradient-danger text-destructive-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="shadow-medical">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getRiskIcon()}
              <div>
                <CardTitle className="text-2xl">Risk Assessment Results</CardTitle>
                <CardDescription>Patient: {patientName}</CardDescription>
              </div>
            </div>
            <Badge className={getRiskBadgeColor()}>
              {assessment.riskLevel} Risk
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Main Risk Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-medical">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Overall Risk Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">
                  {assessment.overallRisk}%
                </div>
                <Progress 
                  value={assessment.overallRisk} 
                  className="h-3"
                />
              </div>
              <p className="text-sm text-muted-foreground text-center">
                Based on comprehensive analysis of {Object.keys(assessment.factors).length} risk factors
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-medical">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Model Confidence</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">
                  {assessment.confidence}%
                </div>
                <Progress 
                  value={assessment.confidence} 
                  className="h-3"
                />
              </div>
              <p className="text-sm text-muted-foreground text-center">
                AI model prediction accuracy: {assessment.modelAccuracy}%
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-medical">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Risk Level</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-4">
              <div className="w-32 h-32 mx-auto">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      outerRadius={50}
                      fill="#8884d8"
                      dataKey="value"
                      startAngle={90}
                      endAngle={450}
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <Badge className={getRiskBadgeColor()}>
                {assessment.riskLevel} Risk Category
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Risk Factor Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-medical">
          <CardHeader>
            <CardTitle>Risk Factor Breakdown</CardTitle>
            <CardDescription>Individual contribution to overall risk score</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={factorData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value}%`, 'Risk Contribution']} />
                <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow-medical">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <CardTitle>Risk Trend Projection</CardTitle>
            </div>
            <CardDescription>Projected risk reduction with intervention</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value}%`, 'Risk Score']} />
                <Line 
                  type="monotone" 
                  dataKey="risk" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', strokeWidth: 2, r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card className="shadow-medical">
        <CardHeader>
          <CardTitle>Medical Recommendations</CardTitle>
          <CardDescription>
            Personalized recommendations based on risk assessment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {assessment.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                <CheckCircle className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
                <p className="text-sm">{recommendation}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}