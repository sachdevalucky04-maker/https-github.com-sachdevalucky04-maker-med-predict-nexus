import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search, Filter, FileText, Calendar, User } from "lucide-react";
import { PatientData } from "./PatientForm";
import { RiskAssessment } from "./RiskDashboard";

export interface PatientRecord extends PatientData {
  id: string;
  dateCreated: string;
  lastAssessment: string;
  riskLevel: "Low" | "Medium" | "High";
  riskScore: number;
}

interface PatientRecordsProps {
  records: PatientRecord[];
  onSelectPatient: (record: PatientRecord) => void;
  onViewAssessment: (record: PatientRecord) => void;
}

export function PatientRecords({ records, onSelectPatient, onViewAssessment }: PatientRecordsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterRisk, setFilterRisk] = useState<string>("all");

  const filteredRecords = records.filter(record => {
    const matchesSearch = record.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterRisk === "all" || record.riskLevel.toLowerCase() === filterRisk;
    
    return matchesSearch && matchesFilter;
  });

  const getRiskBadgeColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'Low':
        return 'bg-gradient-success text-accent-foreground';
      case 'Medium':
        return 'bg-gradient-warning text-warning-foreground';
      case 'High':
        return 'bg-gradient-danger text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Card className="w-full shadow-medical">
      <CardHeader>
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-gradient-primary rounded-lg">
            <FileText className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <CardTitle className="text-2xl">Patient Records</CardTitle>
            <CardDescription>
              Manage and review patient cancer risk assessments
            </CardDescription>
          </div>
        </div>

        {/* Search and Filter Controls */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or patient ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex gap-2">
            <Button
              variant={filterRisk === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterRisk("all")}
              className="flex items-center gap-2"
            >
              <Filter className="h-4 w-4" />
              All Risks
            </Button>
            <Button
              variant={filterRisk === "low" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterRisk("low")}
              className="text-accent"
            >
              Low
            </Button>
            <Button
              variant={filterRisk === "medium" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterRisk("medium")}
              className="text-warning"
            >
              Medium
            </Button>
            <Button
              variant={filterRisk === "high" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterRisk("high")}
              className="text-destructive"
            >
              High
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {filteredRecords.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Records Found</h3>
            <p className="text-muted-foreground">
              {searchTerm || filterRisk !== "all" 
                ? "No patient records match your search criteria."
                : "No patient records available. Create a new assessment to get started."
              }
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead>Age</TableHead>
                  <TableHead>Gender</TableHead>
                  <TableHead>Risk Level</TableHead>
                  <TableHead>Risk Score</TableHead>
                  <TableHead>Last Assessment</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecords.map((record) => (
                  <TableRow key={record.id} className="hover:bg-muted/50">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-muted rounded-full">
                          <User className="h-4 w-4" />
                        </div>
                        <div>
                          <div className="font-medium">{record.name}</div>
                          <div className="text-sm text-muted-foreground">
                            ID: {record.id}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    
                    <TableCell>{record.age}</TableCell>
                    
                    <TableCell className="capitalize">{record.gender}</TableCell>
                    
                    <TableCell>
                      <Badge className={getRiskBadgeColor(record.riskLevel)}>
                        {record.riskLevel}
                      </Badge>
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="font-semibold">{record.riskScore}%</div>
                        <div className="w-12 h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary transition-all"
                            style={{ width: `${record.riskScore}%` }}
                          />
                        </div>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        {formatDate(record.lastAssessment)}
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onSelectPatient(record)}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => onViewAssessment(record)}
                          className="bg-gradient-primary hover:opacity-90"
                        >
                          View Assessment
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}