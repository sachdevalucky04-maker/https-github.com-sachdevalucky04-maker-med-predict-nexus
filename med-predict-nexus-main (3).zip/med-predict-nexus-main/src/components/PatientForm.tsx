import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Stethoscope, User, Activity } from "lucide-react";

export interface PatientData {
  id?: string;
  name: string;
  age: number;
  gender: string;
  smokingHistory: string;
  alcoholConsumption: string;
  physicalActivity: string;
  familyHistory: string;
  previousCancer: boolean;
  symptom1: string;
  symptom2: string;
  testResults: {
    bloodPressure: string;
    cholesterol: number;
    bloodSugar: number;
    bmi: number;
  };
  medicalHistory: string;
}

interface PatientFormProps {
  onSubmit: (data: PatientData) => void;
  initialData?: Partial<PatientData>;
  isLoading?: boolean;
}

export function PatientForm({ onSubmit, initialData, isLoading = false }: PatientFormProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState<PatientData>({
    name: initialData?.name || "",
    age: initialData?.age || 0,
    gender: initialData?.gender || "",
    smokingHistory: initialData?.smokingHistory || "",
    alcoholConsumption: initialData?.alcoholConsumption || "",
    physicalActivity: initialData?.physicalActivity || "",
    familyHistory: initialData?.familyHistory || "",
    previousCancer: initialData?.previousCancer || false,
    symptom1: initialData?.symptom1 || "",
    symptom2: initialData?.symptom2 || "",
    testResults: {
      bloodPressure: initialData?.testResults?.bloodPressure || "",
      cholesterol: initialData?.testResults?.cholesterol || 0,
      bloodSugar: initialData?.testResults?.bloodSugar || 0,
      bmi: initialData?.testResults?.bmi || 0,
    },
    medicalHistory: initialData?.medicalHistory || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.age || !formData.gender) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields (Name, Age, Gender)",
        variant: "destructive",
      });
      return;
    }

    onSubmit(formData);
    toast({
      title: "Patient Data Submitted",
      description: "Cancer risk analysis is being processed...",
    });
  };

  const updateFormData = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const updateTestResults = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      testResults: {
        ...prev.testResults,
        [field]: value
      }
    }));
  };

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-form">
      <CardHeader className="pb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-primary rounded-lg">
            <Stethoscope className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <CardTitle className="text-2xl">Patient Information</CardTitle>
            <CardDescription>Enter patient details for cancer risk assessment</CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <User className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">Basic Information</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => updateFormData("name", e.target.value)}
                  placeholder="Enter patient name"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="age">Age *</Label>
                <Input
                  id="age"
                  type="number"
                  value={formData.age || ""}
                  onChange={(e) => updateFormData("age", parseInt(e.target.value))}
                  placeholder="Enter age"
                  min="1"
                  max="120"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Select value={formData.gender} onValueChange={(value) => updateFormData("gender", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Lifestyle Factors */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Lifestyle Factors</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="smoking">Smoking History</Label>
                <Select value={formData.smokingHistory} onValueChange={(value) => updateFormData("smokingHistory", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select smoking history" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="never">Never smoked</SelectItem>
                    <SelectItem value="former">Former smoker</SelectItem>
                    <SelectItem value="current">Current smoker</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="alcohol">Alcohol Consumption</Label>
                <Select value={formData.alcoholConsumption} onValueChange={(value) => updateFormData("alcoholConsumption", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select alcohol consumption" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="light">Light (1-2 drinks/week)</SelectItem>
                    <SelectItem value="moderate">Moderate (3-7 drinks/week)</SelectItem>
                    <SelectItem value="heavy">Heavy (8+ drinks/week)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="activity">Physical Activity</Label>
                <Select value={formData.physicalActivity} onValueChange={(value) => updateFormData("physicalActivity", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select activity level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary</SelectItem>
                    <SelectItem value="light">Light exercise</SelectItem>
                    <SelectItem value="moderate">Moderate exercise</SelectItem>
                    <SelectItem value="intense">Intense exercise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Medical History */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">Medical History</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="family">Family History of Cancer</Label>
                <Select value={formData.familyHistory} onValueChange={(value) => updateFormData("familyHistory", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select family history" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No family history</SelectItem>
                    <SelectItem value="distant">Distant relatives</SelectItem>
                    <SelectItem value="close">Close relatives</SelectItem>
                    <SelectItem value="immediate">Immediate family</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="previous">Previous Cancer History</Label>
                <Select 
                  value={formData.previousCancer ? "yes" : "no"} 
                  onValueChange={(value) => updateFormData("previousCancer", value === "yes")}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Previous cancer history" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="no">No</SelectItem>
                    <SelectItem value="yes">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="medical-history">Additional Medical History</Label>
              <Textarea
                id="medical-history"
                value={formData.medicalHistory}
                onChange={(e) => updateFormData("medicalHistory", e.target.value)}
                placeholder="Enter any additional medical history, conditions, or medications..."
                rows={3}
              />
            </div>
          </div>

          {/* Test Results */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Test Results</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bp">Blood Pressure</Label>
                <Input
                  id="bp"
                  value={formData.testResults.bloodPressure}
                  onChange={(e) => updateTestResults("bloodPressure", e.target.value)}
                  placeholder="120/80"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cholesterol">Cholesterol (mg/dL)</Label>
                <Input
                  id="cholesterol"
                  type="number"
                  value={formData.testResults.cholesterol || ""}
                  onChange={(e) => updateTestResults("cholesterol", parseInt(e.target.value))}
                  placeholder="200"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="sugar">Blood Sugar (mg/dL)</Label>
                <Input
                  id="sugar"
                  type="number"
                  value={formData.testResults.bloodSugar || ""}
                  onChange={(e) => updateTestResults("bloodSugar", parseInt(e.target.value))}
                  placeholder="100"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bmi">BMI</Label>
                <Input
                  id="bmi"
                  type="number"
                  step="0.1"
                  value={formData.testResults.bmi || ""}
                  onChange={(e) => updateTestResults("bmi", parseFloat(e.target.value))}
                  placeholder="25.0"
                />
              </div>
            </div>
          </div>

          {/* Current Symptoms */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Current Symptoms</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="symptom1">Primary Symptom</Label>
                <Input
                  id="symptom1"
                  value={formData.symptom1}
                  onChange={(e) => updateFormData("symptom1", e.target.value)}
                  placeholder="Enter primary symptom"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="symptom2">Secondary Symptom</Label>
                <Input
                  id="symptom2"
                  value={formData.symptom2}
                  onChange={(e) => updateFormData("symptom2", e.target.value)}
                  placeholder="Enter secondary symptom"
                />
              </div>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-gradient-primary hover:opacity-90 text-primary-foreground"
            disabled={isLoading}
          >
            {isLoading ? "Analyzing..." : "Analyze Cancer Risk"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}