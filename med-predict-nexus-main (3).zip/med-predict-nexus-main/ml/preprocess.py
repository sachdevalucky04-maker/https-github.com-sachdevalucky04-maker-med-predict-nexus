import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import joblib
import os

class DataPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_columns = []
        
    def preprocess_data(self, df, is_training=True):
        """
        Preprocess patient data for ML models
        
        Args:
            df (DataFrame): Raw patient data
            is_training (bool): Whether this is training data
            
        Returns:
            DataFrame: Processed features
        """
        # Make a copy to avoid modifying original data
        data = df.copy()
        
        # Handle missing values
        data = self._handle_missing_values(data)
        
        # Feature engineering
        data = self._engineer_features(data)
        
        # Encode categorical variables
        data = self._encode_categorical(data, is_training)
        
        # Select and order features
        if is_training:
            self.feature_columns = [col for col in data.columns if col != 'cancer_diagnosis']
        
        # Ensure consistent feature ordering
        data = data[self.feature_columns + (['cancer_diagnosis'] if 'cancer_diagnosis' in data.columns else [])]
        
        # Scale numerical features
        if is_training:
            numerical_cols = self._get_numerical_columns(data)
            data[numerical_cols] = self.scaler.fit_transform(data[numerical_cols])
        else:
            numerical_cols = self._get_numerical_columns(data)
            data[numerical_cols] = self.scaler.transform(data[numerical_cols])
        
        return data
    
    def _handle_missing_values(self, data):
        """Handle missing values in the dataset"""
        # Fill numerical columns with median
        numerical_cols = data.select_dtypes(include=[np.number]).columns
        for col in numerical_cols:
            data[col].fillna(data[col].median(), inplace=True)
        
        # Fill categorical columns with mode
        categorical_cols = data.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            data[col].fillna(data[col].mode()[0] if not data[col].mode().empty else 'Unknown', inplace=True)
        
        return data
    
    def _engineer_features(self, data):
        """Create new features from existing ones"""
        # BMI calculation if height and weight are available
        if 'height' in data.columns and 'weight' in data.columns:
            data['bmi'] = data['weight'] / ((data['height'] / 100) ** 2)
            data['bmi_category'] = pd.cut(data['bmi'], 
                                        bins=[0, 18.5, 25, 30, float('inf')],
                                        labels=['underweight', 'normal', 'overweight', 'obese'])
        
        # Age groups
        if 'age' in data.columns:
            data['age_group'] = pd.cut(data['age'],
                                     bins=[0, 30, 50, 70, float('inf')],
                                     labels=['young', 'middle_aged', 'senior', 'elderly'])
        
        # Risk factors combination
        risk_factors = ['smoking', 'drinking', 'familyHistory']
        available_risk_factors = [col for col in risk_factors if col in data.columns]
        if available_risk_factors:
            data['total_risk_factors'] = data[available_risk_factors].sum(axis=1)
        
        # Exercise score
        if 'exerciseFrequency' in data.columns:
            exercise_mapping = {'never': 0, 'rarely': 1, 'sometimes': 2, 'often': 3, 'daily': 4}
            data['exercise_score'] = data['exerciseFrequency'].map(exercise_mapping).fillna(0)
        
        return data
    
    def _encode_categorical(self, data, is_training):
        """Encode categorical variables"""
        categorical_cols = data.select_dtypes(include=['object']).columns
        categorical_cols = [col for col in categorical_cols if col != 'cancer_diagnosis']
        
        for col in categorical_cols:
            if is_training:
                le = LabelEncoder()
                data[col] = le.fit_transform(data[col].astype(str))
                self.label_encoders[col] = le
            else:
                if col in self.label_encoders:
                    # Handle unseen categories
                    le = self.label_encoders[col]
                    data[col] = data[col].astype(str)
                    data[col] = data[col].apply(lambda x: le.transform([x])[0] if x in le.classes_ else -1)
        
        return data
    
    def _get_numerical_columns(self, data):
        """Get numerical columns for scaling"""
        return data.select_dtypes(include=[np.number]).columns.tolist()
    
    def prepare_single_prediction(self, patient_data):
        """
        Prepare single patient data for prediction
        
        Args:
            patient_data (dict): Patient information
            
        Returns:
            np.array: Processed features for prediction
        """
        # Convert to DataFrame
        df = pd.DataFrame([patient_data])
        
        # Preprocess
        processed_df = self.preprocess_data(df, is_training=False)
        
        # Return as numpy array
        return processed_df.values
    
    def save_preprocessor(self, path='models/'):
        """Save the preprocessor components"""
        os.makedirs(path, exist_ok=True)
        
        # Save scaler
        joblib.dump(self.scaler, os.path.join(path, 'scaler.pkl'))
        
        # Save label encoders
        joblib.dump(self.label_encoders, os.path.join(path, 'label_encoders.pkl'))
        
        # Save feature columns
        joblib.dump(self.feature_columns, os.path.join(path, 'feature_columns.pkl'))
    
    def load_preprocessor(self, path='models/'):
        """Load the preprocessor components"""
        try:
            self.scaler = joblib.load(os.path.join(path, 'scaler.pkl'))
            self.label_encoders = joblib.load(os.path.join(path, 'label_encoders.pkl'))
            self.feature_columns = joblib.load(os.path.join(path, 'feature_columns.pkl'))
            return True
        except FileNotFoundError:
            print("Preprocessor files not found. Please train the model first.")
            return False

def create_sample_dataset(n_samples=1000):
    """Create a sample dataset for testing"""
    np.random.seed(42)
    
    data = {
        'age': np.random.randint(20, 80, n_samples),
        'gender': np.random.choice(['Male', 'Female'], n_samples),
        'smoking': np.random.choice([0, 1], n_samples, p=[0.7, 0.3]),
        'drinking': np.random.choice([0, 1], n_samples, p=[0.6, 0.4]),
        'familyHistory': np.random.choice([0, 1], n_samples, p=[0.8, 0.2]),
        'exerciseFrequency': np.random.choice(['never', 'rarely', 'sometimes', 'often', 'daily'], n_samples),
        'height': np.random.normal(170, 10, n_samples),
        'weight': np.random.normal(70, 15, n_samples),
    }
    
    df = pd.DataFrame(data)
    
    # Create synthetic cancer diagnosis based on risk factors
    risk_score = (
        df['age'] * 0.02 +
        df['smoking'] * 0.3 +
        df['drinking'] * 0.1 +
        df['familyHistory'] * 0.4 +
        (df['exerciseFrequency'].map({'never': 0.2, 'rarely': 0.1, 'sometimes': 0, 'often': -0.1, 'daily': -0.2})) +
        np.random.normal(0, 0.1, n_samples)
    )
    
    # Convert to binary classification
    df['cancer_diagnosis'] = (risk_score > np.percentile(risk_score, 80)).astype(int)
    
    return df