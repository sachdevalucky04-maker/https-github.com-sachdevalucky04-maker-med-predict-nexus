import joblib
import numpy as np
import os
from ml.preprocess import DataPreprocessor

class CancerPredictor:
    def __init__(self, model_path='models/'):
        self.model_path = model_path
        self.model = None
        self.model_name = None
        self.preprocessor = DataPreprocessor()
        self.load_model()
    
    def load_model(self):
        """Load the trained model and preprocessor"""
        try:
            # Load best model
            self.model = joblib.load(os.path.join(self.model_path, 'best_model.pkl'))
            self.model_name = joblib.load(os.path.join(self.model_path, 'best_model_name.pkl'))
            
            # Load preprocessor
            self.preprocessor.load_preprocessor(self.model_path)
            
            print(f"Loaded model: {self.model_name}")
            return True
            
        except FileNotFoundError as e:
            print(f"Model files not found: {e}")
            print("Please train the model first by running: python ml/train.py")
            return False
    
    def predict_single(self, patient_data):
        """
        Predict cancer risk for a single patient
        
        Args:
            patient_data (dict): Patient information
            
        Returns:
            tuple: (risk_score, risk_level, confidence)
        """
        if self.model is None:
            raise ValueError("Model not loaded. Please train the model first.")
        
        try:
            # Preprocess patient data
            processed_data = self.preprocessor.prepare_single_prediction(patient_data)
            
            # Make prediction
            prediction_proba = self.model.predict_proba(processed_data)[0]
            risk_score = float(prediction_proba[1])  # Probability of positive class
            
            # Determine risk level
            risk_level = self._get_risk_level(risk_score)
            
            # Calculate confidence (max probability)
            confidence = float(max(prediction_proba))
            
            return risk_score, risk_level, confidence
            
        except Exception as e:
            print(f"Prediction error: {e}")
            raise
    
    def _get_risk_level(self, risk_score):
        """Convert risk score to risk level"""
        if risk_score < 0.3:
            return "Low"
        elif risk_score < 0.7:
            return "Medium"
        else:
            return "High"
    
    def predict_batch(self, patient_data_list):
        """
        Predict cancer risk for multiple patients
        
        Args:
            patient_data_list (list): List of patient dictionaries
            
        Returns:
            list: List of prediction tuples
        """
        predictions = []
        for patient_data in patient_data_list:
            try:
                prediction = self.predict_single(patient_data)
                predictions.append(prediction)
            except Exception as e:
                print(f"Error predicting for patient: {e}")
                predictions.append((0.0, "Unknown", 0.0))
        
        return predictions

# Global predictor instance
_predictor = None

def get_predictor():
    """Get or create global predictor instance"""
    global _predictor
    if _predictor is None:
        _predictor = CancerPredictor()
    return _predictor

def predict_cancer_risk(patient_data):
    """
    Main prediction function for Flask API
    
    Args:
        patient_data (dict): Patient information
        
    Returns:
        tuple: (risk_score, risk_level, confidence)
    """
    predictor = get_predictor()
    return predictor.predict_single(patient_data)

# Example usage and testing
def test_prediction():
    """Test the prediction functionality"""
    # Sample patient data
    test_patients = [
        {
            'age': 45,
            'gender': 'Male',
            'smoking': 1,
            'drinking': 0,
            'familyHistory': 1,
            'exerciseFrequency': 'rarely',
            'height': 175,
            'weight': 80
        },
        {
            'age': 30,
            'gender': 'Female',
            'smoking': 0,
            'drinking': 0,
            'familyHistory': 0,
            'exerciseFrequency': 'daily',
            'height': 165,
            'weight': 60
        },
        {
            'age': 65,
            'gender': 'Male',
            'smoking': 1,
            'drinking': 1,
            'familyHistory': 1,
            'exerciseFrequency': 'never',
            'height': 170,
            'weight': 90
        }
    ]
    
    predictor = CancerPredictor()
    
    if predictor.model is not None:
        print("Testing predictions...")
        for i, patient in enumerate(test_patients, 1):
            try:
                risk_score, risk_level, confidence = predictor.predict_single(patient)
                print(f"\nPatient {i}:")
                print(f"  Age: {patient['age']}, Gender: {patient['gender']}")
                print(f"  Risk Score: {risk_score:.3f}")
                print(f"  Risk Level: {risk_level}")
                print(f"  Confidence: {confidence:.3f}")
            except Exception as e:
                print(f"Error predicting patient {i}: {e}")
    else:
        print("Model not available for testing")

if __name__ == "__main__":
    test_prediction()