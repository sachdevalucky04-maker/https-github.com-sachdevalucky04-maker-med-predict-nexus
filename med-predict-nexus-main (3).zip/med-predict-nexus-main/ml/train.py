import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, classification_report, confusion_matrix
import joblib
import os
import json
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from ml.preprocess import DataPreprocessor, create_sample_dataset

def train_models(data_path=None, test_size=0.2, random_state=42):
    """
    Train multiple ML models for cancer prediction
    
    Args:
        data_path (str): Path to training data CSV file
        test_size (float): Proportion of data for testing
        random_state (int): Random seed
        
    Returns:
        dict: Training results and model performance
    """
    print("Starting model training...")
    
    # Load or create dataset
    if data_path and os.path.exists(data_path):
        df = pd.read_csv(data_path)
        print(f"Loaded dataset from {data_path}")
    else:
        print("Creating sample dataset...")
        df = create_sample_dataset(n_samples=5000)
    
    print(f"Dataset shape: {df.shape}")
    print(f"Cancer cases: {df['cancer_diagnosis'].sum()} ({df['cancer_diagnosis'].mean():.2%})")
    
    # Initialize preprocessor
    preprocessor = DataPreprocessor()
    
    # Preprocess data
    print("Preprocessing data...")
    processed_df = preprocessor.preprocess_data(df, is_training=True)
    
    # Split features and target
    X = processed_df.drop('cancer_diagnosis', axis=1)
    y = processed_df['cancer_diagnosis']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Test set: {X_test.shape[0]} samples")
    
    # Define models
    models = {
        'logistic_regression': LogisticRegression(random_state=random_state, max_iter=1000),
        'decision_tree': DecisionTreeClassifier(random_state=random_state),
        'random_forest': RandomForestClassifier(random_state=random_state, n_estimators=100),
        'svm': SVC(random_state=random_state, probability=True),
        'neural_network': MLPClassifier(random_state=random_state, max_iter=1000)
    }
    
    # Train and evaluate models
    results = {}
    best_model = None
    best_score = 0
    
    print("\nTraining models...")
    for name, model in models.items():
        print(f"\nTraining {name}...")
        
        # Train model
        model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = model.predict(X_test)
        y_pred_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else y_pred
        
        # Calculate metrics
        metrics = {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred),
            'recall': recall_score(y_test, y_pred),
            'f1_score': f1_score(y_test, y_pred),
            'roc_auc': roc_auc_score(y_test, y_pred_proba)
        }
        
        # Cross-validation score
        cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='roc_auc')
        metrics['cv_score_mean'] = cv_scores.mean()
        metrics['cv_score_std'] = cv_scores.std()
        
        results[name] = metrics
        
        print(f"Accuracy: {metrics['accuracy']:.4f}")
        print(f"ROC-AUC: {metrics['roc_auc']:.4f}")
        print(f"CV Score: {metrics['cv_score_mean']:.4f} (+/- {metrics['cv_score_std']*2:.4f})")
        
        # Track best model
        if metrics['roc_auc'] > best_score:
            best_score = metrics['roc_auc']
            best_model = (name, model)
    
    # Save best model and preprocessor
    os.makedirs('models', exist_ok=True)
    
    print(f"\nBest model: {best_model[0]} (ROC-AUC: {best_score:.4f})")
    joblib.dump(best_model[1], 'models/best_model.pkl')
    joblib.dump(best_model[0], 'models/best_model_name.pkl')
    
    # Save preprocessor
    preprocessor.save_preprocessor('models/')
    
    # Save all models
    for name, model in models.items():
        joblib.dump(model, f'models/{name}.pkl')
    
    # Generate visualizations
    generate_training_visualizations(results, y_test, models, X_test)
    
    # Save results
    results_with_metadata = {
        'timestamp': datetime.now().isoformat(),
        'dataset_shape': df.shape,
        'best_model': best_model[0],
        'models': results
    }
    
    with open('reports/training_results.json', 'w') as f:
        json.dump(results_with_metadata, f, indent=2)
    
    print("\nTraining completed!")
    print(f"Best model saved as 'models/best_model.pkl'")
    print(f"Results saved in 'reports/training_results.json'")
    
    return results_with_metadata

def generate_training_visualizations(results, y_test, models, X_test):
    """Generate training visualization reports"""
    os.makedirs('reports', exist_ok=True)
    
    # Model comparison plot
    plt.figure(figsize=(12, 8))
    
    metrics = ['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc']
    model_names = list(results.keys())
    
    x = np.arange(len(model_names))
    width = 0.15
    
    for i, metric in enumerate(metrics):
        values = [results[model][metric] for model in model_names]
        plt.bar(x + i*width, values, width, label=metric, alpha=0.8)
    
    plt.xlabel('Models')
    plt.ylabel('Score')
    plt.title('Model Performance Comparison')
    plt.xticks(x + width*2, model_names, rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.savefig('reports/model_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # Feature importance for Random Forest
    if 'random_forest' in models:
        rf_model = models['random_forest']
        feature_importance = rf_model.feature_importances_
        feature_names = [f'feature_{i}' for i in range(len(feature_importance))]
        
        plt.figure(figsize=(10, 6))
        indices = np.argsort(feature_importance)[::-1][:10]  # Top 10 features
        
        plt.bar(range(len(indices)), feature_importance[indices])
        plt.title('Top 10 Feature Importances (Random Forest)')
        plt.xlabel('Features')
        plt.ylabel('Importance')
        plt.xticks(range(len(indices)), [feature_names[i] for i in indices], rotation=45)
        plt.tight_layout()
        plt.savefig('reports/feature_importance.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    print("Visualizations saved in 'reports/' directory")

def hyperparameter_tuning(X_train, y_train):
    """Perform hyperparameter tuning for best models"""
    print("Performing hyperparameter tuning...")
    
    # Random Forest tuning
    rf_params = {
        'n_estimators': [50, 100, 200],
        'max_depth': [None, 10, 20, 30],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }
    
    rf = RandomForestClassifier(random_state=42)
    rf_grid = GridSearchCV(rf, rf_params, cv=3, scoring='roc_auc', n_jobs=-1)
    rf_grid.fit(X_train, y_train)
    
    print(f"Best Random Forest params: {rf_grid.best_params_}")
    print(f"Best Random Forest score: {rf_grid.best_score_:.4f}")
    
    # Save tuned model
    joblib.dump(rf_grid.best_estimator_, 'models/random_forest_tuned.pkl')
    
    return rf_grid.best_estimator_

if __name__ == "__main__":
    # Create reports directory
    os.makedirs('reports', exist_ok=True)
    
    # Train models
    results = train_models()
    print("\nTraining completed successfully!")