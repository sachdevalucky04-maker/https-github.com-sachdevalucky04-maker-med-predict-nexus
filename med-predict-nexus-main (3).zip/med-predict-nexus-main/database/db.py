import mysql.connector
from mysql.connector import Error
import os
from config import Config
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_db_connection():
    """
    Create and return a database connection
    
    Returns:
        mysql.connector.connection: Database connection object
    """
    try:
        connection = mysql.connector.connect(
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE,
            autocommit=False
        )
        
        if connection.is_connected():
            return connection
            
    except Error as e:
        logger.error(f"Error connecting to MySQL: {e}")
        raise

def init_db():
    """Initialize the database with schema"""
    try:
        # First, connect without specifying database to create it
        connection = mysql.connector.connect(
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD
        )
        
        cursor = connection.cursor()
        
        # Create database if it doesn't exist
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.MYSQL_DATABASE}")
        cursor.execute(f"USE {Config.MYSQL_DATABASE}")
        
        # Read and execute schema file
        schema_path = os.path.join(os.path.dirname(__file__), 'schema.sql')
        if os.path.exists(schema_path):
            with open(schema_path, 'r') as f:
                schema_sql = f.read()
            
            # Split by semicolon and execute each statement
            statements = schema_sql.split(';')
            for statement in statements:
                statement = statement.strip()
                if statement and not statement.startswith('--'):
                    try:
                        cursor.execute(statement)
                    except Error as e:
                        # Log warning for minor errors but continue
                        if "already exists" not in str(e):
                            logger.warning(f"SQL execution warning: {e}")
            
            connection.commit()
            logger.info("Database initialized successfully")
        else:
            logger.warning("Schema file not found")
        
        cursor.close()
        connection.close()
        
    except Error as e:
        logger.error(f"Error initializing database: {e}")
        raise

def execute_query(query, params=None, fetch=False):
    """
    Execute a database query
    
    Args:
        query (str): SQL query
        params (tuple): Query parameters
        fetch (bool): Whether to fetch results
        
    Returns:
        list or None: Query results if fetch=True
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        
        if fetch:
            results = cursor.fetchall()
            return results
        else:
            connection.commit()
            return cursor.rowcount
            
    except Error as e:
        if connection:
            connection.rollback()
        logger.error(f"Database query error: {e}")
        raise
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

def get_patient_by_id(patient_id):
    """Get patient information by ID"""
    query = "SELECT * FROM patients WHERE id = %s"
    results = execute_query(query, (patient_id,), fetch=True)
    return results[0] if results else None

def create_patient(patient_data):
    """Create a new patient record"""
    query = """
        INSERT INTO patients (patient_id, first_name, last_name, date_of_birth, 
                            gender, email, phone, address, emergency_contact)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    params = (
        patient_data.get('patient_id'),
        patient_data.get('first_name'),
        patient_data.get('last_name'),
        patient_data.get('date_of_birth'),
        patient_data.get('gender'),
        patient_data.get('email'),
        patient_data.get('phone'),
        patient_data.get('address'),
        patient_data.get('emergency_contact')
    )
    return execute_query(query, params)

def get_predictions_by_risk_level(risk_level=None, limit=100):
    """Get predictions filtered by risk level"""
    if risk_level:
        query = """
            SELECT * FROM predictions 
            WHERE risk_level = %s 
            ORDER BY created_at DESC 
            LIMIT %s
        """
        params = (risk_level, limit)
    else:
        query = """
            SELECT * FROM predictions 
            ORDER BY created_at DESC 
            LIMIT %s
        """
        params = (limit,)
    
    return execute_query(query, params, fetch=True)

def save_prediction(patient_data, risk_score, risk_level, confidence, patient_id=None, user_id=None):
    """Save a prediction to the database"""
    import json
    
    query = """
        INSERT INTO predictions (patient_id, patient_data, risk_score, risk_level, 
                               confidence, created_by)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    params = (
        patient_id,
        json.dumps(patient_data),
        risk_score,
        risk_level,
        confidence,
        user_id
    )
    return execute_query(query, params)

def get_model_performance():
    """Get the latest model performance metrics"""
    query = """
        SELECT * FROM model_performance 
        WHERE is_active = TRUE 
        ORDER BY training_date DESC 
        LIMIT 1
    """
    results = execute_query(query, fetch=True)
    return results[0] if results else None

def save_model_performance(model_name, model_version, metrics, dataset_size):
    """Save model performance metrics"""
    # First, deactivate all existing models
    execute_query("UPDATE model_performance SET is_active = FALSE")
    
    # Insert new model performance
    query = """
        INSERT INTO model_performance 
        (model_name, model_version, accuracy, precision_score, recall_score, 
         f1_score, roc_auc, dataset_size, is_active)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    params = (
        model_name,
        model_version,
        metrics.get('accuracy'),
        metrics.get('precision'),
        metrics.get('recall'),
        metrics.get('f1_score'),
        metrics.get('roc_auc'),
        dataset_size,
        True
    )
    return execute_query(query, params)

def test_connection():
    """Test database connection"""
    try:
        connection = get_db_connection()
        if connection.is_connected():
            print("Database connection successful!")
            
            # Test query
            cursor = connection.cursor()
            cursor.execute("SELECT DATABASE()")
            db_name = cursor.fetchone()[0]
            print(f"Connected to database: {db_name}")
            
            # Check tables
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            print(f"Available tables: {[table[0] for table in tables]}")
            
            cursor.close()
            connection.close()
            return True
    except Error as e:
        print(f"Database connection failed: {e}")
        return False

if __name__ == "__main__":
    # Test the database connection
    print("Testing database connection...")
    if test_connection():
        print("Database setup completed successfully!")
    else:
        print("Database setup failed!")