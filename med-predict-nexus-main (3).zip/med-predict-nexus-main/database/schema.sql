-- Cancer Prediction Database Schema
-- MySQL/MariaDB compatible

-- Create database
CREATE DATABASE IF NOT EXISTS cancer_prediction;
USE cancer_prediction;

-- Users table for authentication
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('doctor', 'admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Patients table
CREATE TABLE IF NOT EXISTS patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    emergency_contact VARCHAR(100),
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Medical history table
CREATE TABLE IF NOT EXISTS medical_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    condition_name VARCHAR(100) NOT NULL,
    diagnosis_date DATE,
    status ENUM('active', 'resolved', 'chronic') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

-- Test results table
CREATE TABLE IF NOT EXISTS test_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    test_type VARCHAR(100) NOT NULL,
    test_date DATE NOT NULL,
    result_value DECIMAL(10,4),
    result_unit VARCHAR(20),
    reference_range VARCHAR(50),
    status ENUM('normal', 'abnormal', 'critical') DEFAULT 'normal',
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Predictions table - stores ML model predictions
CREATE TABLE IF NOT EXISTS predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NULL,  -- Can be NULL for anonymous predictions
    patient_data JSON NOT NULL,  -- Store input features as JSON
    risk_score DECIMAL(5,4) NOT NULL,  -- Probability score (0-1)
    risk_level ENUM('Low', 'Medium', 'High') NOT NULL,
    confidence DECIMAL(5,4) NOT NULL,  -- Model confidence
    model_version VARCHAR(50) DEFAULT 'v1.0',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_risk_level (risk_level),
    INDEX idx_created_at (created_at)
);

-- Model performance tracking
CREATE TABLE IF NOT EXISTS model_performance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    model_name VARCHAR(100) NOT NULL,
    model_version VARCHAR(50) NOT NULL,
    accuracy DECIMAL(5,4),
    precision_score DECIMAL(5,4),
    recall_score DECIMAL(5,4),
    f1_score DECIMAL(5,4),
    roc_auc DECIMAL(5,4),
    training_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dataset_size INT,
    is_active BOOLEAN DEFAULT FALSE,  -- Only one model should be active
    notes TEXT
);

-- Audit log for tracking changes
CREATE TABLE IF NOT EXISTS audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    old_values JSON,
    new_values JSON,
    user_id INT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, email, password_hash, role) VALUES 
('admin', 'admin@cancerprediction.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewMoNGnLRSDSlBnO', 'admin')
ON DUPLICATE KEY UPDATE username=username;

-- Insert sample doctor user (password: doctor123)
INSERT INTO users (username, email, password_hash, role) VALUES 
('doctor1', 'doctor1@cancerprediction.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewMoNGnLRSDSlBnO', 'doctor')
ON DUPLICATE KEY UPDATE username=username;

-- Create indexes for better performance
CREATE INDEX idx_patients_patient_id ON patients(patient_id);
CREATE INDEX idx_predictions_patient_id ON predictions(patient_id);
CREATE INDEX idx_test_results_patient_id ON test_results(patient_id);
CREATE INDEX idx_medical_history_patient_id ON medical_history(patient_id);

-- Create views for common queries
CREATE OR REPLACE VIEW patient_summary AS
SELECT 
    p.id,
    p.patient_id,
    CONCAT(p.first_name, ' ', p.last_name) AS full_name,
    p.date_of_birth,
    TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) AS age,
    p.gender,
    p.email,
    p.phone,
    COUNT(DISTINCT mh.id) AS conditions_count,
    COUNT(DISTINCT tr.id) AS tests_count,
    COUNT(DISTINCT pred.id) AS predictions_count,
    MAX(pred.risk_level) AS latest_risk_level,
    MAX(pred.created_at) AS latest_prediction_date
FROM patients p
LEFT JOIN medical_history mh ON p.id = mh.patient_id
LEFT JOIN test_results tr ON p.id = tr.patient_id
LEFT JOIN predictions pred ON p.id = pred.patient_id
GROUP BY p.id;

-- Create view for recent predictions
CREATE OR REPLACE VIEW recent_predictions AS
SELECT 
    pred.id,
    pred.patient_id,
    CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
    pred.risk_score,
    pred.risk_level,
    pred.confidence,
    pred.created_at,
    u.username AS created_by_user
FROM predictions pred
LEFT JOIN patients p ON pred.patient_id = p.id
LEFT JOIN users u ON pred.created_by = u.id
ORDER BY pred.created_at DESC;

-- Sample data insertion (optional)
-- Uncomment the following lines to insert sample data

/*
-- Sample patients
INSERT INTO patients (patient_id, first_name, last_name, date_of_birth, gender, email, phone) VALUES
('P001', 'John', 'Doe', '1980-05-15', 'Male', 'john.doe@email.com', '+1234567890'),
('P002', 'Jane', 'Smith', '1975-08-22', 'Female', 'jane.smith@email.com', '+1234567891'),
('P003', 'Robert', 'Johnson', '1965-12-10', 'Male', 'robert.j@email.com', '+1234567892');

-- Sample medical history
INSERT INTO medical_history (patient_id, condition_name, diagnosis_date, status) VALUES
(1, 'Hypertension', '2020-01-15', 'chronic'),
(1, 'Diabetes Type 2', '2019-06-20', 'chronic'),
(2, 'Asthma', '2018-03-10', 'active'),
(3, 'Heart Disease', '2021-09-05', 'active');

-- Sample test results
INSERT INTO test_results (patient_id, test_type, test_date, result_value, result_unit, status) VALUES
(1, 'PSA', '2023-01-15', 4.2, 'ng/mL', 'abnormal'),
(1, 'CEA', '2023-01-15', 2.1, 'ng/mL', 'normal'),
(2, 'CA 125', '2023-02-20', 15.0, 'U/mL', 'normal'),
(3, 'AFP', '2023-03-10', 8.5, 'ng/mL', 'normal');
*/